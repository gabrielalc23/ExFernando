<?php
function calcularAurea($altura){
    $aurea = 1.618;
return $altura * $aurea;
}
function main(){
    while (True){
        $altura = float($_GET['aurea']);
        if ($altura <= 0){
            echo "<p>A altura deve ser um número positivo. Tente novamente </p>";
            continue;

        }
        $comprimento = calcularAurea($altura);
        echo ("O comprimento ideal para o prédio é $comprimento");
        $continuar = $_GET[''];
    }
}
?>