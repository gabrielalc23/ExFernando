function mudainput(){
    let input     = document.querySelector('.calcAurea');   
    let calcular  = document.querySelector('.calcular');
    let respostas = document.querySelector('repostas');

    calcular.setAttribute()
}